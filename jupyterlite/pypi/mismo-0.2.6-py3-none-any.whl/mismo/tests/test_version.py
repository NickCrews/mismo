from __future__ import annotations

import mismo


def test_version():
    assert isinstance(mismo.__version__, str)
